close all
clear all
d1=[8 12.3 7 11 7.3 10 10.4 9.7 9.7 11.7 11 8.7 9.5 10.1 9.6 10.5 9.2 11.3 10.1 8.5 ]; 
d2=[6 12.5 7.3 9 9.1 10.7 9.8 10.0 10.1 11.5 10.8 8.8 9.3 9.4 9.6 10.4 9.0 11.6 9.8 9.2]; 
P=1-0.95
[PCA]=pca_ellipse(d1', d2', P);

plot(d1,d2,'o')
hold on
plot(PCA.X(:,1),PCA.X(:,2),'r.')
hold on
plot(PCA.up_bound(:,1),PCA.up_bound(:,2),'r-');
hold on
plot(PCA.low_bound(:,1),PCA.low_bound(:,2),'g-');
grid on
axis([4 15 4 15])
set(gcf,'PaperPositionMode','auto')
set(gcf,'Position',[0 0 450 450]);
xlabel('Observation 1')
ylabel('Observation 2')
title(['P=',num2str(P)])
%
