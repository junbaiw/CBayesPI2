function [PCA]=pca_ellipse(Ch1, Ch2, stds)
%make PCA ellipse for quality control of two replicated experiments
%IN:
%Ch1, is a data vector nx1 for experiment 1
%Ch2 is a data vector nx1 for experiment 2
%stds is standard deviation of PCA ellipse, or the significant level of a PCA ellipse please see detail 
%description bellow
%stds=2 represents around 95.45% of data included in PCA ellipse, 
%stds=3 represents around 99.73% of data included in PCA ellipse
%stds=4 represents around 99.994% of data included in PCA ellipse
%if stds<1, then it is a p-value for PCA ellipse
%Out:
%tag_theta: tangent of the first principal angle
%tag_theta: tangent of the second principal angle
%upper: coordinate of the first PCA, the major axis of PCA ellipse
%lower: coordinate of the second PCA, the minor axis of PCA ellipse
%X:	is the PCA ellipse
%yscore: yscore of PCA
%Tscore: Tscore of PCA
%tD: is T^2 value of the PCA ellipse
%S: is the covariance matrice of [Ch1, Ch2]
%U: is the eigenvalue to S
%l: is the eigenvector to S
%V: is scaled eigenvalue to S, V=sqrt(l)*U;

%author Junbai Wang, Pathology Department, Oslo University Hospital
%2013 Nov.
%the implementation is based on chapter 1 and chapter 15 of book 
%"A user's guide to principal components" J.E. Jackson 1991
%
%marray_tDistribution is borrowed from Marray toolbox 
%http://www.mathworks.com/matlabcentral/fileexchange/14634-marray

olddata=[Ch1,Ch2];
qdata=olddata;  % Data For PCA Calculations
qdata2=olddata; % Whole Data for calculate T-Score.

s=cov(qdata);
[U, l, EXPLAINED] = pcacov(s);
%calculate tin(theta) of first PCA;
cos_theta=U(1,1);
theta=acos(cos_theta)*180/pi;
theta2=theta+90;

sin_theta=sqrt(1-cos_theta^2);
tag_theta=tan(theta/180*pi);
tag_theta2=tan(theta2/180*pi);

V=sqrt(ones(size(U,1),1)*l').*U;
mdata=mean(qdata); %Standards for the whole data set. 
meandata= ones(size(qdata2,1),1)*mdata;
submean2=qdata2-meandata;

for i=1:length(submean2)
    z(i,:)=[U'*submean2(i,:)']';
end
sqrtl=ones(size(qdata2,1),1)*sqrt(l)';
yscore=z./sqrtl;

%added jbw 09/04
Tscore=diag(yscore*yscore');

%Calculatge T score distribution in 95% limits
%2STD=0.9545, 3STD=0.9973, 4STD=0.99994
%if matlab statistic toolbox is available then marray_tDistribution can be replaced by
%  tD=p*(n-1)/(n-p)*finv(1-alpha,p,n-p)
%
disp(['Tscore for ', num2str(stds),' STD'])
if stds==4
     tD=marray_tDistribution(2,length(qdata),1-0.99994);
elseif stds==3
     tD=marray_tDistribution(2,length(qdata),1-0.9973);
elseif stds==2
     tD=marray_tDistribution(2,length(qdata),1-0.9545);
else 
    tD=marray_tDistribution(2,length(qdata),stds);
end
x=1:length(qdata2);

%Calculate Quality control ellipse
h=0;
g=sqrt(tD);
upper(1,:)=[mdata'+g.*V(:,1)+h.*V(:,2)]';
upper(2,:)=[mdata'-g.*V(:,1)+h.*V(:,2)]';

g=0;
h=sqrt(tD);
lower(1,:)=[mdata'+g.*V(:,1)+h.*V(:,2)]';
lower(2,:)=[mdata'+g.*V(:,1)-h.*V(:,2)]';
X(1:2,:)=upper;
X(3:4,:)=lower;

h=[-sqrt(tD):0.01:sqrt(tD)];
clear g
g(:,1)=sqrt(tD*ones(size(h))-h.^2)';
g(:,2)=-sqrt(tD*ones(size(h))-h.^2)';
for k=1:length(h)
    X(k+4,:)=[mdata'+g(k,1).*V(:,1)+h(k).*V(:,2)]';
end
for k=1:length(h)
    X(length(h)+k+4,:)=[mdata'+g(k,2).*V(:,1)+h(k).*V(:,2)]';
end
g=[-sqrt(tD):0.01:sqrt(tD)];
clear h
h(:,1)=sqrt(tD*ones(size(g))-g.^2)';
h(:,2)=-sqrt(tD*ones(size(g))-g.^2)';
for k=1:length(g)
    X(length(g)*2+k+4,:)=[mdata'+g(k).*V(:,1)+h(k,1).*V(:,2)]';
end
for k=1:length(g)
    X(length(g)*3+k+4,:)=[mdata'+g(k).*V(:,1)+h(k,2).*V(:,2)]';
end


%assign data to final export format
PCA.tag_theta=tag_theta;
PCA.tag_theta2=tag_theta2;
PCA.up_bound=upper;
PCA.low_bound=lower;
PCA.X=X;
PCA.yscore=yscore;
PCA.Tscore=Tscore;
PCA.tD=tD;
PCA.U=U;
PCA.l=l;
PCA.V=V;
PCA.S=s;
PCA.zscore=z;
PCA.semiminor=sqrt(l(2)*tD);
PCA.semimajor=sqrt(l(1)*tD);
