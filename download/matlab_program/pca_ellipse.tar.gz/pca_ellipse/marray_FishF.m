function rr=marray_FishF(f,n1,n2) 
% 
%Fisher F-Distribution, input: f , n1 is number of groups, n2 is the total number
%of subjects in experiment minues number of groups.
% output is the probability of  F-distributions.
PiD2=pi/2;
x=n2/(n1*f+n2);
 if mod(n1,2)==0 
    rr=marray_StatCom(1-x,n2,n1+n2-4,n2-2)*power(x,n2/2) ;
    return   
 end
 
 if mod(n2,2)==0 
    rr=1-marray_StatCom(x,n1,n1+n2-4,n1-2)*power(1-x,n1/2) ;
    return   
 end
 %%%%%%%%%%%%%%%%%%%%%
 th=atan(sqrt(n1*f/n2)); 
 a=th/PiD2; 
 sth=sin(th); 
 cth=cos(th);
 if n2>1
    a=a+sth*cth*marray_StatCom(cth*cth,2,n2-3,-1)/PiD2  ;
 end
 if n1==1 
    rr=1-a ;
    return
 end
 c=4*marray_StatCom(sth*sth,n2+1,n1+n2-4,n2-2)*sth*power(cth,n2)/pi;
 if n2==1  
    rr=1-a+c/2 ;
    return
 end
 k=2; 
 while k<=(n2-1)/2
    c=c*k/(k-0.5); k=k+1; 
 end
rr=1-a+c;
return
 