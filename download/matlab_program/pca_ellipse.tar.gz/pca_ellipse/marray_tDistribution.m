function result=marray_tDistribution(p,n,alpha)
%The distribution of T score 
%
%p is number of experiments,
%n is number of objects in each experiments
%alpha is the tail of probability.
result=p*(n-1)/(n-p)*marray_AFishF(alpha,p,n-p);
 

