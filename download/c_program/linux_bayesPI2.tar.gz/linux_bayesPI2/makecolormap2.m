function redgreen = makecolormap2(nlev,colors);
%rg means red and green
%bw means black and white
%
%make red/green color map
%nlev = 10;

if colors=='rg' 
	for i=1:nlev,
  		redgreen(i,:)      = [0,(nlev-i+1)*(1.0/nlev),0]; 
	end
	redgreen(nlev+1,:) = [0,0,0];
	for i=1:nlev,
  		redgreen(nlev+1+i,:) = [i*(1.0/nlev),0,0];
	end
elseif colors=='bw'
	for i=1:nlev,
                redgreen(i,:)   = [0,(nlev-i+1)*(1.0/nlev),0];
        end
        redgreen(nlev+1,:) = [0,0,0];
        for i=1:nlev,
                redgreen(nlev+1+i,:) = [i*(1.0/nlev),0,0];
        end
	[rows,cols]=size(redgreen);
	redgreen(ceil(rows/2),:)=[1 1 1];
	%redgreen(1:ceil(rows/2)-1,1)=flipud(redgreen(1:ceil(rows/2)-1,2));
	%redgreen(1:ceil(rows/2)-1,3)=flipud(redgreen(1:ceil(rows/2)-1,2));
	%redgreen(ceil(rows/2)+1:end,1)=flipud(redgreen(ceil(rows/2)+1:end,2));
	%redgreen(ceil(rows/2)+1:end,3)=flipud(redgreen(ceil(rows/2)+1:end,2));
	redgreen=repmat(redgreen(ceil(rows/2)+1:end,1),1,3);
	redgreen=flipud(redgreen);
elseif colors=='rw'
%red white and green color
	%for i=1:nlev  %green to white
	%	redgreen(i,:)=[ (nlev-i+1)*(1/nlev), 1, (nlev-i+1)*(1/nlev) ];
	%end

%	redgreen=[1:-1/nlev:0.1; repmat(1,1,nlev); 1:-1/nlev:0.1 ]';
 	redgreen=[1:-1/nlev:1/nlev; repmat(1,1,nlev); 1:-1/nlev:1/nlev ]';

	redgreen=flipud(redgreen);
        %for i=1:nlev, %red to white
        %         redgreen(nlev+i,:)   = [1,(nlev-i+1)*(1.0/nlev),(nlev-i+1)*(1/nlev)];
        % end
	redgreen=[redgreen; [repmat(1,1,nlev); 1:-1/nlev:1/nlev ; 1:-1/nlev:1/nlev]'];
	
	%find repeated color white then remove it
  	idx=find(sum(abs(redgreen-repmat([1 1 1],size(redgreen,1),1)),2)==0);
	if ~isempty(idx)
		if length(idx)>1
			row_idx=1:size(redgreen,1);
			new_idx=setdiff(row_idx,idx(1));
			redgreen=redgreen(new_idx,:);
		end
	end
end
return;
