close all
clear all
f1='out/in/Hnf4a_v2/Hnf4a_2640.2_v2_deBruijn.txt_Int_Wij_L12_1.intect'

[d,v,c]=tblread(f1,'\t');
[row,col]=size(d);
d2=d.*(d<0);
imagesc(exp(-d2').*(d2<0)');

%colormap(pink)
nlevels=4;
redgreen=makecolormap2(nlevels,'bw');
cmin=0;
cmax=5;
colormap(redgreen);
caxis([cmin,cmax]);
colorbar
xtick_pos=1:row;
set(gca,'Xtick',xtick_pos);
set(gca,'XtickLabel',c);
ytick_pos=1:16;
set(gca,'Ytick',ytick_pos);
set(gca,'YtickLabel',v);
yl=ylabel('Dinucleotide')
xl=xlabel('Dinucleotide interaction position')
tl=title('Hnf4a dinucleotide energy-dependence exp(-E)')
set(xl,'FontSize',15);
set(yl,'FontSize',15);
set(tl,'FontSize',15);
set(gca,'FontSize',15);
grid on;

set(gcf,'PaperPositionMode','auto')
set(gcf,'Position',[0 0 900 600]);
fig_name=[f1,'.jpg']
eval(['print -djpeg -r300 ', fig_name]);

